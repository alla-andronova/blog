<template>
    <div>
        <h1 class="success"> You successfully added a new post!</h1>
        <a href"#">Click here to see your new post</a>
    </div>
</template>

<script>

</script>

<style>
.success {
    text-align: center;
    color: green;
}
</style>