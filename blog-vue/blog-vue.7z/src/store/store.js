import { createStore } from 'vuex' // есть в дефолт

// этого всего нет в дефолт
//import Vue from 'vue'
//import store from './store'
//import Vuex from 'vuex'
// Vue.use(Vuex)
//  export default new Vuex.Store({})
// до сюда


export default createStore({
    state: {
    },
    mutations: {
    },
    actions: {
    },
    modules: {
    }
  })