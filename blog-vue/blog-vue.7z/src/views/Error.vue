<template>
    <h1 class="error">ERROR 404</h1>
</template>

<script>

</script>

<style>
.error {
    text-align: center;
    color: darkred;
}
</style>