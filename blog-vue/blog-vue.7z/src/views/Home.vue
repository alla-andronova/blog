<template>
<p>This is Home</p>
</template>

<script>

export default {
  
}
</script>
